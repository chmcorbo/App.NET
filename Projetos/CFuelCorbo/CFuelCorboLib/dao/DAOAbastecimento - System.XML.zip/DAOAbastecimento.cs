﻿
namespace CFuelCorboLib.dao
{
    using System;
    using CFuelCorboLib.dominio;
    using CorboUtils.DAO;
    using System.Xml;
    using System.Collections.Generic;
    using CorboUtils.DataHora;

    public class DAOAbastecimento : DAOBase
    {
        Boolean erro = false;
        String caminho_arquivo;

        XmlDocument xmldoc;
        XmlNode xmlregistro;
        XmlElement xmlid;
        XmlElement xmldata_abastec;
        XmlElement xmlhora_abastec;
        XmlElement xmlid_tipo_combust;
        XmlElement xmlkm;
        XmlElement xmllitragem;
        XmlElement xmlkm_litro;
        XmlElement xmlvalor_unit;
        XmlElement xmlvalor_total;
        XmlElement xmlid_posto;
        XmlElement xmlobservacao;

        public DAOAbastecimento(String caminho)
        {
            criarCampos();
            caminho_arquivo = caminho + @"\abastecimento.xml";
            xmldoc.Load(caminho_arquivo);

        }
        
        private void criarCampos()
        {
            xmldoc = new XmlDocument();
            // Campos;
            xmlid = xmldoc.CreateElement("id");
            xmldata_abastec = xmldoc.CreateElement("data_abastec");
            xmlhora_abastec = xmldoc.CreateElement("hora_abastec");
            xmlid_tipo_combust = xmldoc.CreateElement("id_tipo_combustivel");
            xmlkm = xmldoc.CreateElement("km");
            xmllitragem = xmldoc.CreateElement("litragem");
            xmlkm_litro = xmldoc.CreateElement("km_litro");
            xmlvalor_unit = xmldoc.CreateElement("valor_unit");
            xmlvalor_total = xmldoc.CreateElement("valor_total");
            xmlid_posto = xmldoc.CreateElement("id_posto");
            xmlobservacao = xmldoc.CreateElement("observacao");
        }

        private void salvarXML()
        {
            xmldoc.Save(caminho_arquivo);
        }

        public override bool inserir(CorboUtils.Dominio.ClasseBase obj)
        {
            XmlElement xmlNovoRegistro = xmldoc.CreateElement("abastecimento");
            try
            {
                xmlid.InnerText = DataLib.getID().ToString();
                xmldata_abastec.InnerText = ((Abastecimento)obj).data_abastec.ToString();
                xmlhora_abastec.InnerText = ((Abastecimento)obj).hora_abastec.ToString();
                xmlid_tipo_combust.InnerText = ((Abastecimento)obj).combustivel.ID.ToString();
                xmlkm.InnerText = ((Abastecimento)obj).km.ToString();
                xmllitragem.InnerText = ((Abastecimento)obj).litragem.ToString();
                xmlkm_litro.InnerText = ((Abastecimento)obj).km_litro.ToString();
                xmlvalor_unit.InnerText = ((Abastecimento)obj).valor_unit.ToString();
                xmlvalor_total.InnerText = ((Abastecimento)obj).valor_total.ToString();
                xmlid_posto.InnerText = ((Abastecimento)obj).posto.ID.ToString();
                xmlobservacao.InnerText = ((Abastecimento)obj).observacao;

                xmlNovoRegistro.AppendChild(xmlid);
                xmlNovoRegistro.AppendChild(xmldata_abastec);
                xmlNovoRegistro.AppendChild(xmlhora_abastec);
                xmlNovoRegistro.AppendChild(xmlid_tipo_combust);
                xmlNovoRegistro.AppendChild(xmlkm);
                xmlNovoRegistro.AppendChild(xmllitragem);
                xmlNovoRegistro.AppendChild(xmlkm_litro);
                xmlNovoRegistro.AppendChild(xmlvalor_unit);
                xmlNovoRegistro.AppendChild(xmlvalor_total);
                xmlNovoRegistro.AppendChild(xmlid_posto);
                xmlNovoRegistro.AppendChild(xmlobservacao);

                xmldoc.DocumentElement.AppendChild(xmlNovoRegistro);
                salvarXML();
            }
            catch (Exception e)
            {
                erro = true;
                throw new Exception("Erro ao inserir o lançamento de abastecimento. " + e.Message);
            }
            finally
            {
                erro = false;
            }
            return !erro;
        }

        public override bool alterar(CorboUtils.Dominio.ClasseBase obj)
        {
            
            try
            {
                if (buscarIDxml(ref xmlregistro, obj))
                {
                    xmlregistro["data_abastec"].InnerText = ((Abastecimento)obj).data_abastec.ToString();
                    xmlregistro["hora_abastec"].InnerText = ((Abastecimento)obj).hora_abastec.ToString(); ;
                    xmlregistro["id_tipo_combustivel"].InnerText = ((Abastecimento)obj).combustivel.ID.ToString();
                    xmlregistro["km"].InnerText = ((Abastecimento)obj).km.ToString(); ;
                    xmlregistro["litragem"].InnerText = ((Abastecimento)obj).litragem.ToString(); ;
                    xmlregistro["km_litro"].InnerText = ((Abastecimento)obj).km_litro.ToString(); ;
                    xmlregistro["valor_unit"].InnerText = ((Abastecimento)obj).valor_unit.ToString(); ;
                    xmlregistro["valor_total"].InnerText = ((Abastecimento)obj).valor_total.ToString(); ;
                    xmlregistro["id_posto"].InnerText = ((Abastecimento)obj).posto.ID.ToString();
                    xmlregistro["observacao"].InnerText = ((Abastecimento)obj).observacao;
                    salvarXML();
                }
            }
            catch (Exception e)
            {
                erro = true;
                throw new Exception("Erro ao alterar o lançamento de abastecimento. " + e.Message);
            }
            finally
            {
                erro = false;
            }
            return !erro;
        }

        public override bool excluir(CorboUtils.Dominio.ClasseBase obj)
        {
            try
            {
                if (buscarIDxml(ref xmlregistro, obj))
                {
                    xmlregistro.ParentNode.RemoveChild(xmlregistro);
                    salvarXML();
                }
            }
            catch (Exception e)
            {
                erro = true;
                throw new Exception("Erro ao alterar o lançamento de abastecimento. " + e.Message);
            }
            finally
            {
                erro = false;
            }
            return !erro;
        }

        private bool buscarIDxml(ref XmlNode xmlresult,CorboUtils.Dominio.ClasseBase obj)
        {
            Boolean encontrado = false;
            foreach (XmlNode xmlregistro in xmldoc.DocumentElement.ChildNodes)
            {
                if (Int32.Parse(xmlregistro["id"].InnerText) == obj.ID)
                {
                    xmlresult = xmlregistro;
                    encontrado = true;
                    break;
                }
            }
            return encontrado;
        }

        public override bool buscarID(CorboUtils.Dominio.ClasseBase obj)
        {
            try
            {
                /*var abastecimento = from a in xmldoc. veiculos.Elements("veiculo")
                              where (string)v.Attribute("id") == "2"
                              select new
                              {
                                  placa = a.Element("placa"),
                                  marca = a.Element("marca"),
                                  modelo = a.Element("modelo"),
                                  cor = a.Element("cor")
                              };
                */
                

                buscarIDxml(ref xmlregistro, obj);
                ((Abastecimento)obj).ID = Int32.Parse(xmlregistro["id"].InnerText);
                ((Abastecimento)obj).data_abastec = DateTime.Parse(xmlregistro["data_abastec"].InnerText);
                ((Abastecimento)obj).hora_abastec = DateTime.Parse(xmlregistro["hora_abastec"].InnerText);
                ((Abastecimento)obj).combustivel.ID = Int32.Parse(xmlregistro["id_tipo_combustivel"].InnerText);
                ((Abastecimento)obj).km = Int32.Parse(xmlregistro["km"].InnerText);
                ((Abastecimento)obj).litragem = Double.Parse(xmlregistro["litragem"].InnerText);
                ((Abastecimento)obj).km_litro = Double.Parse(xmlregistro["km_litro"].InnerText);
                ((Abastecimento)obj).valor_unit = Double.Parse(xmlregistro["valor_unit"].InnerText);
                ((Abastecimento)obj).valor_total = Double.Parse(xmlregistro["valor_total"].InnerText);
                ((Abastecimento)obj).posto.ID = Int32.Parse(xmlregistro["id_posto"].InnerText);
                ((Abastecimento)obj).observacao = xmlregistro["observacao"].InnerText;
                 
            }
            catch (Exception e)
            {
                erro = true;
                throw new Exception("Erro ao consultar o lançamento de abastecimento. " + e.Message);
            }
            finally
            {
                erro = false;
            }

            return !erro;
        }
        public List<Abastecimento> listar()
        {
            List<Abastecimento> lista = new List<Abastecimento>();
            Abastecimento abastecimento;
            
            foreach (XmlNode xmlregistro in xmldoc.DocumentElement.ChildNodes)
            {
                abastecimento = new Abastecimento();
                abastecimento.ID = Int32.Parse(xmlregistro["id"].InnerText);
                abastecimento.data_abastec = DateTime.Parse(xmlregistro["data_abastec"].InnerText);
                abastecimento.hora_abastec = DateTime.Parse(xmlregistro["hora_abastec"].InnerText);
                abastecimento.combustivel.ID = Int32.Parse(xmlregistro["id_tipo_combustivel"].InnerText);
                abastecimento.km = Int32.Parse(xmlregistro["km"].InnerText);
                abastecimento.litragem = Double.Parse(xmlregistro["litragem"].InnerText);
                abastecimento.km_litro = Double.Parse(xmlregistro["km_litro"].InnerText);
                abastecimento.valor_unit = Double.Parse(xmlregistro["valor_unit"].InnerText);
                abastecimento.valor_total = Double.Parse(xmlregistro["valor_total"].InnerText);
                abastecimento.posto.ID = Int32.Parse(xmlregistro["id_posto"].InnerText);
                abastecimento.observacao = xmlregistro["observacao"].InnerText;
                lista.Add(abastecimento);
            }

            return lista;
        }

    }
}
