﻿/// <summary>
/// Persistência de Frentista
/// </summary>


namespace cave.DAO.financeiro
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Text;
    using System.Collections.Generic;
    using cave.dominio.financeiro;
    using cave.dominio.seguranca;
    using cave.DAO.seguranca;
    using Sigleton.Conexao;
    using solucon.dominio;
    using solucon.DAO;
    using solucon.state;


    public class DAOFrentista : DAOBase
    {
        private DAOUsuario daoUsuario;

        public DAOFrentista()
        {
            daoUsuario = new DAOUsuario();
        }

        public override bool alterar(ClasseBase obj)
        {
            if (daoUsuario == null)
                daoUsuario = new DAOUsuario();
            return daoUsuario.alterar((Usuario)obj);
        }

        public override bool buscarID(ClasseBase obj)
        {
            throw new NotImplementedException();
        }

        public override bool excluir(ClasseBase obj)
        {
            throw new NotImplementedException();
        }

        public override bool inserir(ClasseBase obj)
        {
            throw new NotImplementedException();
        }

        public bool validaFornecedor(ClasseBase obj)
        {
            SqlCommand command = new SqlCommand();
            Int32 co;
            bool resultado = false;
            try
            {
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = "SELECT COUNT(ID_FORNECEDOR) AS CO FROM USUARIO " +
                    "WHERE ID='" + ((Frentista)obj).ID + "' and ID_FORNECEDOR NOT IS NULL";
                co = (Int32)command.ExecuteScalar();
                resultado = (co > 0);
            }
            finally
            {
                command.Connection.Close();
            }
            return resultado;
        }
    }
}