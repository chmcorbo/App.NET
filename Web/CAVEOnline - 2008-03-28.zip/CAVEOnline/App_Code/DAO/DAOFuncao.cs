﻿/// <summary>
/// Persistência de função
/// </summary>
///


namespace cave.DAO.RH
{
    using solucon.dominio;
    using solucon.DAO;
    using cave.dominio.RH;
    using Sigleton.Conexao;
    using System;
    using System.Data.SqlClient;
    using System.Text;

    public class DAOFuncao : DAOBase
    {
        private SqlCommand command;
        private StringBuilder vsql;

        public DAOFuncao()
        {
            command = new SqlCommand();
            vsql = new StringBuilder();
        }

        #region IDAOBase Members

        public override bool alterar(ClasseBase obj)
        {
            bool erro = true;
            try
            {
                vsql.Append("UPDATE FUNCAO SET DESCRICAO='" + ((Funcao)obj).Nome.ToUpper() + "' " +
                    "WHERE ID=" + ((Funcao)obj).ID);
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (System.Exception e)
            {
                erro = false;
                throw new Exception("Erro ao alterar a função. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }

        public override bool excluir(ClasseBase obj)
        {
            bool erro = true;
            try
            {
                vsql.Append("DELETE FROM FUNCAO WHERE ID=" + ((Funcao)obj).ID);
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao excluir a função. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public override bool inserir(ClasseBase obj)
        {
            bool erro = true;
            try
            {
                vsql.Append("INSERT INTO FUNCAO ");
                vsql.Append("(NOME) ");
                vsql.Append("VALUES ");
                vsql.Append("('" + ((Funcao)obj).Nome.ToUpper() + ")");
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao inserir a função. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }

        public override bool buscarID(ClasseBase obj)
        {
            bool erro = true;
            SqlDataReader reader;
            try
            {
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = "SELECT ID,DESCRICAO FROM FUNCAO " +
                    "WHERE ID=" + ((Funcao)obj).ID.ToString();
                reader = command.ExecuteReader();
                if (reader.Read())
                {
                    ((Funcao)obj).Nome = reader["DESCRICAO"].ToString();
                }
                else
                {
                    erro = false;
                }
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }

        #endregion

        public void listar()
        {
            //throw new System.NotImplementedException();
        }

        public bool verifNome(Funcao obj)
        {
            bool resultado = false;
            Int32 co;
            try
            {
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = "SELECT COUNT(NOME) AS CO FROM FUNCAO " +
                    "WHERE NOME='" + ((Funcao)obj).Nome+"' and ID="+((Funcao)obj).ID.ToString();
                co =(Int32)command.ExecuteScalar();
                resultado = (co > 0);
            }
            finally
            {
                command.Connection.Close();
            }
            return resultado;
        }
    }
}