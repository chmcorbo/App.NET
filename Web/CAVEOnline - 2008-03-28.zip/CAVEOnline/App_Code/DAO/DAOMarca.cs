﻿/// <summary>
/// Persistência de marca veículo
/// </summary>

namespace cave.DAO.veiculo
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Text;
    using System.Collections.Generic;
    using Sigleton.Conexao;
    using solucon.dominio;
    using solucon.DAO;
    using solucon.state;
    using cave.dominio.veiculo;
    using cave.DAO.veiculo;

    public class DAOMarca : DAOBase
    {
        private SqlCommand command;
        private StringBuilder vsql;

        public DAOMarca()
        {
            command = new SqlCommand();
            vsql = new StringBuilder();
        }

        public override bool inserir(ClasseBase obj)
        {
            bool erro = true;
            try
            {
                vsql.Append("INSERT INTO MARCA ");
                vsql.Append("(NOME) ");
                vsql.Append("VALUES ");
                vsql.Append("('" + ((Marca)obj).Descricao.ToUpper()+ ")");
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao inserir a marca. " + e.Message);

            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public override bool alterar(ClasseBase obj)
        {
            bool erro = true;
            try
            {
                vsql.Append("UPDATE MARCA SET DESCRICAO='" + ((Marca)obj).Descricao.ToUpper() +"' "+
                    "WHERE ID=" + ((Marca)obj).ID);
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao alterar a marca. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public override bool excluir(ClasseBase obj)
        {
            bool erro = true;
            try
            {
                vsql.Append("DELETE FROM MARCA WHERE ID=" + ((Marca)obj).ID);
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao excluir a marca. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public override bool buscarID(ClasseBase obj)
        {
            bool erro = true;
            try
            {
                SqlDataReader reader;
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = "SELECT ID,DESCRICAO FROM MARCA " +
                    "WHERE ID=" + ((Marca)obj).ID.ToString();
                reader = command.ExecuteReader();
                if (reader.Read())
                {
                    ((Marca)obj).Descricao = reader["DESCRICAO"].ToString();
                }
                else
                {
                    erro = false;
                }
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public List<Marca> listar()
        {
            List<Marca> lista = new List<Marca>();
            Int32 x = 0;

            try
            {
                SqlDataReader reader;
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                vsql.Append("SELECT ID, DESCRICAO FROM MARCA ");
                vsql.Append("ORDER BY DESCRICAO ");
                command.CommandText = vsql.ToString();
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    lista.Add(new Marca());
                    lista[x].ID = Convert.ToInt32(reader["ID"]);
                    lista[x].Descricao = reader["DESCRICAO"].ToString();
                    x++;
                }
                return lista;
            }
            catch (Exception e)
            {
                throw new Exception("Erro ao montar a lista de marca. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
        }
        public bool verifDescricao(Marca obj)
        {
            Int32 co;
            bool resultado = false;
            try
            {
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = "SELECT COUNT(DESCRICAO) AS CO FROM MARCA " +
                    "WHERE NOME='" + ((Marca)obj).Descricao + "' and ID=" + ((Marca)obj).ID.ToString();
                co = (Int32)command.ExecuteScalar();
                resultado = (co > 0);
            }
            finally
            {
                command.Connection.Close();
            }
            return resultado;
        }
    }
}