﻿using System;
using cave.dominio.RH;

/// <summary>
/// Summary description for Teste
/// </summary>
public class Cliente : ICRUD
{
    private Int32 id;
    private String nome;
    private DateTime dt_nascimento;
    private Int32 tipo;

    public Int32 ID
    {
        get { return id; }
        set { id = value; }
    }

    public String getNome()
    {
        return nome; 
    }

    public void setNome(String value)
    {
        nome=value;
    }

    public DateTime Dt_nascimento
    {
        get; set;
    }

    public Cliente()
    {
        //
        // TODO: Add constructor logic here
        //
    }


    #region ICRUD Members
    public bool inserir()
    {
        // Sem implementação
        return true;
    }

    public bool alterar()
    {
        // Sem implementação
        return true;
    }

    public bool excluir()
    {
        // Sem implementação
        return true;
    }
    #endregion

    public void demitir(Int32 a)
    {
        if (a == 0 && a != 0)
        {
            Funcionario funcionario = new Funcionario();
            funcionario.Estado = solucon.state.Stateobj.stEditar;
        }
    }
    public Double calcularDesconto(Double valor_normal)
    {
        switch (tipo)
        {
            case 1: return (valor_normal * 0.03); 
            case 2: return (valor_normal * 0.05); 
            case 3: return (valor_normal * 0.07); 
            case 4: return (valor_normal * 0.10); 
            case 5: return (valor_normal * 0.15); 
            default : return 0.00;
        }
    }

}
