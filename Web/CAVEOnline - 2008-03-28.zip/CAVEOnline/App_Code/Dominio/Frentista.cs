﻿/// <summary>
/// Classe de domínio Frentista
/// </summary>
///


namespace cave.dominio.financeiro
{

    using System;
    using solucon.dominio;
    using cave.dominio.seguranca;
    using cave.dominio.financeiro;

    public class Frentista : Usuario
    {
        // Fields
        private Fornecedor fornecedor;
        // Propriedades
        public Fornecedor Fornecedor
        {
            get { return fornecedor; }
            set { fornecedor = value; }
        }

        // Métodos 
        public Frentista()
        {
            fornecedor = new Fornecedor();
        }
    }
}