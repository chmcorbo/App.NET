﻿/// <summary>
/// Classe de domínio Funcao
/// </summary>
/// 

namespace cave.dominio.RH
{
    using System;
    using solucon.dominio;

    public class Funcao : ClasseBase
    {
        // Properties
        public String Nome { get; set; }
        // Métodos
        public Funcao()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }

}