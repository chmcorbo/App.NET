﻿/// <summary>
/// Classe de domínio da Marca
/// </summary>
/// 

namespace cave.dominio.veiculo
{
    using System;
    using cave.dominio.veiculo;
    using solucon.dominio;

    public class Marca : ClasseBase
    {
        //Properties
        public String Descricao { get; set; }
        // Métodos
        public Marca()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }        
}