﻿/// <summary>
/// Classe de domínio de Modelo de veículo
/// </summary>
/// 

namespace cave.dominio.veiculo
{
    using System;
    using cave.dominio.veiculo;
    using solucon.dominio;

    public class Modelo : ClasseBase
    {
        // Fields
        private Marca _marca;

        //Properties
        public String Descricao { get; set; }
        public Marca Marca
        {
            get { return _marca; }
            set { _marca = value; }
        }

        // Métodos
        public Modelo()
        {
            _marca = new Marca();
        }
    }
}