﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using cave.dominio.seguranca;
using cave.DAO.seguranca;
using Telerik.Web.UI;

public partial class PesqUsuario : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void RadGrid1_ItemDataBound(object sender, Telerik.Web.UI.GridItemEventArgs e)
    {
        GridDataItem item;
 
        if (e.Item.ItemType == Telerik.Web.UI.GridItemType.Item ||
            e.Item.ItemType == Telerik.Web.UI.GridItemType.AlternatingItem)
        {

            e.Item.Attributes.Add("onmouseover", "this.style.backgroundColor='" + "#E0E0E0" + "'");

            if (e.Item.ItemType == Telerik.Web.UI.GridItemType.AlternatingItem)
                e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor='" + "#F7F7F7" + "'");
            else
                e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor='" + "white" + "'");

            item = e.Item as Telerik.Web.UI.GridDataItem;

            e.Item.Attributes.Add("onclick", "javascript:location.href='" + "cadUsuario.aspx?id=" + item["ID"].Text.Trim() + "';");

            e.Item.Style["cursor"] = "hand"; //' Cursor
        }    
    }
    protected void btnVoltar_Click(object sender, EventArgs e)
    {
        Response.Redirect("principal.aspx");
    }
    protected void btnPesquisar_Click(object sender, EventArgs e)
    {
        Usuario usuario = new Usuario();
        DAOUsuario daoUsuario = new DAOUsuario();
        usuario.Nome = txbNome.Text.ToUpper();
        ObjectDataSource1.TypeName = "cave.DAO.DAOUsuario";
        ObjectDataSource1.DataObjectTypeName = "DAOUsuario";
        ObjectDataSource1.SelectMethod = "DAOUsuario.ListarTudo()";
        RadGrid1.DataSource = ObjectDataSource1;
        RadGrid1.DataBind();
    }
    protected void btnNovo_Click(object sender, EventArgs e)
    {
        Response.Redirect("CadUsuario.aspx");
    }
}
