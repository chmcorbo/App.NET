﻿namespace cave.DAO
{
    using solucon.dominio;
    using solucon.DAO;
    using cave.dominio.RH;

    public class DAOFuncao : IDAOBase
    {
        public DAOFuncao()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        #region IDAOBase Members

        public bool alterar(ClasseBase obj)
        {
            throw new System.NotImplementedException();
        }

        public bool excluir(ClasseBase obj)
        {
            throw new System.NotImplementedException();
        }

        public bool inserir(ClasseBase obj)
        {
            throw new System.NotImplementedException();
        }

        #endregion

        public static void listarTudo()
        {

        }

        public static bool buscarID(Funcao funcao)
        {
            return true;
        }
    }
}