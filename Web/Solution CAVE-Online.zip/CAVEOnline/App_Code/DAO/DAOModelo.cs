﻿namespace cave.DAO
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Text;
    using System.Collections.Generic;
    using cave.dominio;
    using Sigleton.Conexao;
    using solucon.dominio;
    using solucon.DAO;
    using solucon.state;

    public class DAOModelo : DAOBase
    {
        public DAOModelo()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public override bool inserir(ClasseBase obj)
        {
            SqlCommand command = new SqlCommand();
            StringBuilder vsql = new StringBuilder();
            bool erro = true;
            try
            {
                vsql.Append("INSERT INTO MODELO ");
                vsql.Append("(NOME,ID_MARCA) ");
                vsql.Append("VALUES ");
                vsql.Append("('" + ((Modelo)obj).Descricao.ToUpper() + "',"+
                    ((Modelo)obj).Marca.ID.ToString() + ")");
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao inserir registro de modelo. " + e.Message);

            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public override bool alterar(ClasseBase obj)
        {
            SqlCommand command = new SqlCommand();
            StringBuilder vsql = new StringBuilder();
            bool erro = true;
            try
            {
                vsql.Append("UPDATE MODELO SET DESCRICAO='" + 
                    ((Modelo)obj).Descricao.ToUpper() + "', "+
                    "ID_MARCA=" +((Modelo)obj).Marca.ID.ToString()+
                    "WHERE ID=" + ((Marca)obj).ID);
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao alterar registro de modelo. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public override bool excluir(ClasseBase obj)
        {
            SqlCommand command = new SqlCommand();
            StringBuilder vsql = new StringBuilder();
            bool erro = true;
            try
            {
                vsql.Append("DELETE FROM MODELO WHERE ID=" + ((Modelo)obj).ID);
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao excluir registro de marca. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public override bool buscarID(ClasseBase obj)
        {
            SqlCommand command = new SqlCommand();
            SqlDataReader reader;
            bool erro = true;
            try
            {
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = "SELECT ID,DESCRICAO,ID_MARCA FROM MODELO " +
                    "WHERE ID=" + ((Marca)obj).ID.ToString();
                reader = command.ExecuteReader();
                if (reader.Read())
                {
                    ((Modelo)obj).Descricao = reader["DESCRICAO"].ToString();
                    ((Modelo)obj).Marca.ID = Convert.ToInt32(reader["ID_MARCA"]);
                }
                else
                {
                    erro = false;
                }
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public List<Modelo> ListarTudo(Modelo obj)
        {
            SqlCommand command = new SqlCommand();
            SqlDataReader reader;
            List<Modelo> lista = new List<Modelo>();
            StringBuilder vsql = new StringBuilder();
            Int32 x = 0;

            try
            {
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                vsql.Append("SELECT ID, DESCRICAO, ID_MARCA FROM MODELO ");
                vsql.Append("WHERE ID_MARCA=" + obj.ID);
                vsql.Append("ORDER BY DESCRICAO ");
                command.CommandText = vsql.ToString();
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    lista.Add(new Modelo());
                    lista[x].ID = Convert.ToInt32(reader["ID"]);
                    lista[x].Descricao = reader["DESCRICAO"].ToString();
                    lista[x].Marca.ID = Convert.ToInt32(reader["ID_MARCA"]);
                    x++;
                }
                return lista;
            }
            catch (Exception e)
            {
                throw new Exception("Erro ao montar a lista de modelo. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
        }
    }
}



