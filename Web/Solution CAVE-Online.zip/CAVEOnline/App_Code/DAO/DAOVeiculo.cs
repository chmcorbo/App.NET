﻿namespace cave.DAO
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using System.Text;
    using System.Collections.Generic;
    using cave.dominio;
    using cave.dominio.veiculo;
    using Sigleton.Conexao;
    using solucon.dominio;
    using solucon.DAO;
    using solucon.state;

    public class DAOVeiculo : IDAOBase
    {
        public DAOVeiculo()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        private static void parserReaderObj(SqlDataReader reader, ref Veiculo obj) 
        {
            obj.ID = Convert.ToInt32(reader["ID"]);
            obj.Placa = reader["PLACA"].ToString();
            obj.Num_chassi = reader["NUM_CHASSI"].ToString();
            obj.Cor = reader["COR"].ToString();
            obj.Num_portas = Convert.ToInt16(reader["NUM_PORTAS"]);
            obj.Cod_renavam = reader["COD_RENAVAM"].ToString();
            obj.Ano_fab = Convert.ToInt16(reader["ANO_FAB"]);
            obj.Ano_mod = Convert.ToInt16(reader["ANO_MOD"]);
            obj.Cidade = reader["CIDADE"].ToString();
            obj.UF = reader["UF"].ToString();
            obj.Litros_tanque = Convert.ToInt16(reader["LITROS_TANQUE"]);
            obj.Modelo.ID = Convert.ToInt32(reader["ID_MODELO"]);
            obj.Funcionario.ID = Convert.ToInt32(reader["ID_FUNCIONARIO"]);
        }
        private static void SelectPadrao(StringBuilder vsql, ref SqlCommand command)
        {
            vsql.Append("SELECT ID");
            vsql.Append(",PLACA");
            vsql.Append(",NUM_CHASSI");
            vsql.Append(",COR");
            vsql.Append(",NUM_PORTAS");
            vsql.Append(",COD_RENAVAM");
            vsql.Append(",ANO_FAB");
            vsql.Append(",ANO_MOD");
            vsql.Append(",CIDADE");
            vsql.Append(",UF");
            vsql.Append(",LITROS_TANQUE");
            vsql.Append(",ID_MODELO");
            vsql.Append(",ID_FUNCIONARIO ");
            vsql.Append("FROM VEICULO");
            command.CommandText = vsql.ToString();
        }

        public bool inserir(ClasseBase obj)
        {
            SqlCommand command = new SqlCommand();
            StringBuilder vsql = new StringBuilder();
            bool erro = true;
            try
            {
                vsql.Append("INSERT INTO VEICULO ");
                vsql.Append("(PLACA,");
                vsql.Append("NUM_CHASSI,");
                vsql.Append("COR,");
                vsql.Append("NUM_PORTAS,");
                vsql.Append("COD_RENAVAM,");
                vsql.Append("ANO_FAB,");
                vsql.Append("ANO_MOD,");
                vsql.Append("CIDADE,");
                vsql.Append("UF,");
                vsql.Append("LITROS_TANQUE,");
                vsql.Append("ID_MODELO,");
                vsql.Append("ID_FUNCIONARIO)");
                vsql.Append("VALUES ");
                vsql.Append("('" +((Veiculo)obj).Placa + "',");
                vsql.Append("('" +((Veiculo)obj).Num_chassi + "',");
                vsql.Append("('" +((Veiculo)obj).Cor + "',");
                vsql.Append("(" +((Veiculo)obj).Num_portas + ",");
                vsql.Append("('" +((Veiculo)obj).Cod_renavam + "',");
                vsql.Append("(" +((Veiculo)obj).Ano_fab + ",");
                vsql.Append("(" +((Veiculo)obj).Ano_mod + ",");
                vsql.Append("('" +((Veiculo)obj).Cidade + "',");
                vsql.Append("('" +((Veiculo)obj).UF + "',");
                vsql.Append("(" +((Veiculo)obj).Litros_tanque + ",");
                vsql.Append("(" +((Veiculo)obj).Modelo.ID.ToString() + ",");
                vsql.Append("(" +((Veiculo)obj).Funcionario.ID.ToString() + ","); 
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao inserir registro do veículo. " + e.Message);

            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public bool alterar(ClasseBase obj)
        {
            SqlCommand command = new SqlCommand();
            StringBuilder vsql = new StringBuilder();
            bool erro = true;
            try
            {
                vsql.Append("UPDATE VEICULO");
                vsql.Append("SET PLACA = '"+((Veiculo)obj).Placa+"'");
                vsql.Append(",NUM_CHASSI = '"+((Veiculo)obj).Num_chassi+"'");
                vsql.Append(",COR = '"+((Veiculo)obj).Cor+"'");
                vsql.Append(",NUM_PORTAS] = '"+((Veiculo)obj).Num_portas+"'");
                vsql.Append(",COD_RENAVAM = '"+((Veiculo)obj).Cod_renavam+"'");
                vsql.Append(",ANO_FAB = "+((Veiculo)obj).Ano_fab);
                vsql.Append(",ANO_MOD = "+((Veiculo)obj).Ano_mod);
                vsql.Append(",CIDADE = '"+((Veiculo)obj).Cidade+"'");
                vsql.Append(",UF = '"+((Veiculo)obj).UF+"'");
                vsql.Append(",LITROS_TANQUE = '"+((Veiculo)obj).Litros_tanque+"'");
                vsql.Append(",ID_MODELO = "+((Veiculo)obj).Modelo.ID.ToString());
                vsql.Append(",ID_FUNCIONARIO = '"+((Veiculo)obj).Funcionario.ID.ToString()+"  ");
                vsql.Append("WHERE ID=" + ((Marca)obj).ID);
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao alterar registro do veículo. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public bool excluir(ClasseBase obj)
        {
            SqlCommand command = new SqlCommand();
            StringBuilder vsql = new StringBuilder();
            bool erro = true;
            try
            {
                
                vsql.Append("DELETE FROM VEICULO WHERE ID=" + ((Veiculo)obj).ID);
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                command.CommandText = vsql.ToString();
                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                erro = false;
                throw new Exception("Erro ao excluir registro do veículo. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public static bool buscarID(ClasseBase obj)
        {
            SqlCommand command = new SqlCommand();
            SqlDataReader reader;
            StringBuilder vsql = new StringBuilder();
            Veiculo veiculo;
            bool erro = true;
            try
            {
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                SelectPadrao(vsql, ref command);
                vsql.Append(" where id="+((Veiculo)obj).ID.ToString());
                command.CommandText = command.CommandText + vsql.ToString();
                reader = command.ExecuteReader();
                veiculo = ((Veiculo)obj);
                if (reader.Read())
                {
                    parserReaderObj(reader, ref veiculo);
                }
                else
                {
                    erro = false;
                }
            }
            finally
            {
                command.Connection.Close();
            }
            return erro;
        }
        public static List<Veiculo> listar(Veiculo obj)
        {
            SqlCommand command = new SqlCommand();
            SqlDataReader reader;
            List<Veiculo> lista = new List<Veiculo>();
            StringBuilder vsql = new StringBuilder();
            Veiculo veiculo;
            Int32 x = 0;

            try
            {
                command.Connection = SigletonCnxSQL.getConexao();
                command.Connection.Open();
                SelectPadrao(vsql, ref command);
                vsql.Append("ORDER BY DESCRICAO ");
                command.CommandText = command.CommandText+vsql.ToString();
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    lista.Add(new Veiculo());
                    veiculo = lista[x];
                    parserReaderObj(reader, ref veiculo);
                    x++;
                }
                return lista;
            }
            catch (Exception e)
            {
                throw new Exception("Erro ao montar a lista de modelo. " + e.Message);
            }
            finally
            {
                command.Connection.Close();
            }
        }
    }
}