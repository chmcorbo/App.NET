﻿using System;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using cave.dominio;
using cave.DAO;
using solucon.state;


public partial class CadUsuario : System.Web.UI.Page 
{
    
    private Usuario usuario;
    private DAOUsuario daoUsuario;
    
    private void setDados()
    {
        usuario.ID = Convert.ToInt32(txbID.Text);
        usuario.Login = txbLogin.Text;
        usuario.Nome = txbNome.Text;
        usuario.Senha = txbSenha.Text;
        usuario.perfil.ID = Convert.ToInt32(ddPerfil.SelectedValue);
        if (CbAtivo.Checked)
            usuario.Ativo = "S";
        else
            usuario.Ativo = "N";
    }

    private void getDados()
    {
        txbID.Text = usuario.ID.ToString();
        txbLogin.Text = usuario.Login;
        txbNome.Text = usuario.Nome;
        ddPerfil.SelectedValue = usuario.perfil.ID.ToString();
        CbAtivo.Checked=(usuario.Ativo=="S");
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            usuario = new Usuario();

            ddPerfil.DataTextField = "Nome";
            ddPerfil.DataValueField = "ID";
            ddPerfil.DataSource = DAOPerfilUsuario.listar();
            ddPerfil.DataBind();
            txbID.Text = "0";

            if (Request.QueryString["ID"] == "" || Request.QueryString["ID"] == null)
            {
                usuario.Estado = Stateobj.stNovo;
                btnExcluir.Enabled = false;
            }
            else
            {
                usuario.ID = Convert.ToInt32(Request.QueryString["ID"]);
                daoUsuario.buscarID(usuario);
                getDados();
                usuario.Estado = Stateobj.stEditar;
                btnExcluir.Enabled = true;
            }
            Session["usuario"] = usuario;
            Session["daoUsuario"] = daoUsuario;
        }
    }
    private void aplicar(Stateobj estado)
    {
        usuario = (Session["usuario"] as Usuario);
        daoUsuario = (Session["daoUsuario"] as DAOUsuario);
        setDados();
        usuario.Estado = estado;
        usuario.aplicar(daoUsuario);
        Response.Redirect("Principal.aspx");
    }


    protected void btnGravar_Click(object sender, EventArgs e)
    {
        aplicar((Session["usuario"] as Usuario).Estado);
    }
    protected void btnExcluir_Click(object sender, EventArgs e)
    {
        aplicar(Stateobj.stExcluir);
    }

    protected void btnVoltar_Click(object sender, EventArgs e)
    {
        Response.Redirect("Principal.aspx");
    }

    private void InitializeComponent()
    {
        this.Unload += new System.EventHandler(this.CadUsuario_Unload);
        this.Load += new System.EventHandler(this.CadUsuario_Load);

    }

    private void CadUsuario_Unload(object sender, EventArgs e)
    {
        Response.Write("unload");
    }

    private void CadUsuario_Load(object sender, EventArgs e)
    {

    }
}
