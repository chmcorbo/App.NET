﻿namespace solucon.dominio
{
    using System;
    using solucon.state;

    /// <summary>
    /// Summary description for Solucar
    /// </summary>
    /// 

    public abstract class ClasseBase
    {
        // Fields
        private int fid;
        // Properties
        public Stateobj Estado {get; set;}

        public int ID
        {
            get { return fid; }
            set { fid = value; }
        }
        
        // Métodos
        public ClasseBase()
        {
            novo();
        }
     
        public void novo()
        {
            Estado = Stateobj.stNovo;
        }

        public void editar()
        {
            Estado = Stateobj.stEditar;
        }

        public void deletar()
        {
            Estado = Stateobj.stExcluir;
        }
       
        /** Creates a new instance of ClasseBase */
        public bool aplicar(IDAOBase daoObj)
        {
            bool resultado = true;
            switch (this.Estado)
            {
                case Stateobj.stNovo:
                    resultado = daoObj.inserir(this);
                    break;
                case Stateobj.stEditar:
                    resultado = daoObj.alterar(this);
                    break;
                case Stateobj.stExcluir:
                    resultado = daoObj.excluir(this);
                    break;
            }
            return resultado;
        }
    }
}