﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace solucon.dominio
{
    public interface IDAOBase
    {
        bool inserir(ClasseBase obj);
        bool excluir(ClasseBase obj);
        bool alterar(ClasseBase obj);
    }
}
