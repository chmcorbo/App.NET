﻿namespace solucon.state
{
    public enum Stateobj
    {
        stNovo,
        stEditar,
        stExcluir,
        stLimpo
    }
}
