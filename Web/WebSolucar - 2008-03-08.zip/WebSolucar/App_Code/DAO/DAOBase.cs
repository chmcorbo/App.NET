﻿namespace solucon.DAO
{
    using dominio;
    using System;

    /// <summary>
    /// Classe base para persistência de objetos;
    /// </summary>

    public abstract class DAOBase
    {
        // Fields
        // Properties
        // Métodos
        public abstract bool inserir(ClasseBase obj);
        public abstract bool excluir(ClasseBase obj);
        public abstract bool alterar(ClasseBase obj);
        public abstract bool buscarID(ClasseBase obj);
        //public abstract bool buscarID(ClasseBase obj);
        //public abstract vector pesquisa(ClasseBase obj);    
        
        public DAOBase()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public bool aplicar(ClasseBase obj)
        {
            bool resultado = true;
            switch (obj.Estado)
            {
                case Stateobj.stNovo:
                    resultado = this.inserir(obj);
                    break;
                case Stateobj.stEditar:
                    resultado = this.alterar(obj);
                    break;
                case Stateobj.stExcluir:
                    resultado = this.excluir(obj);
                    break;
            }
            return resultado;
        }
    }
}