﻿namespace solucon.dominio
{
    using System;
    enum Stateobj
    {
        stNovo,
        stEditar,
        stExcluir,
        stLimpo
    }

    /// <summary>
    /// Summary description for Solucar
    /// </summary>
    /// 

    public abstract class ClasseBase
    {
        // Fields
        private int fid;
        
        // Properties
        internal Stateobj Estado {get; set;}

        public int ID
        {
            get { return fid; }
            set { fid = value; }
        }
        
        // Métodos
        public ClasseBase()
        {
            novo();
        }
     
        public void novo()
        {
            Estado = Stateobj.stNovo;
        }

        public void editar()
        {
            Estado = Stateobj.stEditar;
        }

        public void deletar()
        {
            Estado = Stateobj.stExcluir;
        }
       
        /** Creates a new instance of ClasseBase */

    }
}