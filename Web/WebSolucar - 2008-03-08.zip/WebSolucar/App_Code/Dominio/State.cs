﻿namespace solucon.State
{
    enum Stateobj
    {
        stNovo,
        stEditar,
        stExcluir,
        stLimpo
    }
}
