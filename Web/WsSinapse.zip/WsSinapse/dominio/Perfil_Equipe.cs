﻿using System;
using simples;

namespace WsSinapse.dominio
{
    public class Perfil_Equipe : ClasseBase
    {
        public Int32 Cod_Perfil_Equipe { get; set; }
        public String Nome { get; set; }
    }
}
