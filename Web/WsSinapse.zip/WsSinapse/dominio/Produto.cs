﻿using System;
using simples;

namespace WsSinapse.dominio
{
    public class Produto : ClasseBase
    {
        public String Codmat { get; set; }
        public String Descricao { get; set; }
        public String Unid { get; set; }
    }
}
